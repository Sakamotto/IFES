package Entidade;

/**
 * Created by 20142BSI0054 on 13/04/2016.
 */
public class Filme extends Espetaculo{

    private String genero, idioma;
    private boolean legendado;
}

package Entidade;

/**
 * Created by 20142BSI0054 on 13/04/2016.
 */
public class Ingresso {
    private double preco;

    public void imprimeIngresso(){
        System.out.println("Imprimir Ingresso ... ");
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }
}

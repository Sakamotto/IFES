package Entidade;

/**
 * Created by 20142BSI0054 on 13/04/2016.
 */
public class Show extends Espetaculo{

    private String tipo;
    private String artista;


}

package Entidade;

/**
 * Created by 20142BSI0054 on 13/04/2016.
 */
public class Especial extends Ingresso{

    private String brinde = "Uma bala! o/";
    private int cadeira;

    public String getBrinde() {
        return brinde;
    }

    public void setBrinde(String brinde) {
        this.brinde = brinde;
    }

    public int getCadeira(){
        return cadeira;
    }

    public void setCadeira(int cadeira) {
        this.cadeira = cadeira;
    }
}

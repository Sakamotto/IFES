package Entidade;

/**
 * Created by 20142BSI0054 on 13/04/2016.
 */
public class Espetaculo {

    private String nome;
    private int idadeMinima, duracao;

}
